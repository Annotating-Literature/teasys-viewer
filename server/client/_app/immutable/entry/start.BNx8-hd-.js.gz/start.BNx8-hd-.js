import{l as o,c as r}from"../chunks/ClOgXLPN.js";export{o as load_css,r as start};
